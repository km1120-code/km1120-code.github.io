# Information Theory Lab

Educational example created for an academic homepage prototype. This repository
uses synthetic data and makes no claim of a published research contribution.
The example is not evidence of any person's education, employment, or authorship.

## Binary channels, entropy, and repetition coding

This example studies a binary symmetric channel (BSC): every transmitted bit
is independently flipped with probability `p`. For `0 <= p <= 0.5`, capacity
is `C = 1 - h_2(p)` bits per channel use. The formula assumes the ordinary
memoryless BSC model and arbitrarily long coding blocks; the demo does not
implement a capacity-achieving code.

A second panel studies a length-three repetition code with majority decoding.
Its rate is `1/3` information bits per channel use. The decoded bit error rate
is exactly `3 p^2 - 2 p^3`. At each channel-noise setting, 100,000 independent
three-bit noise patterns are generated. Markers show the resulting empirical
error rates, not a measurement of channel capacity.

`core.py` also includes mutual information for a normalized discrete joint
probability table. Tests check independent and perfectly dependent examples.

IE is interpreted as Information Engineering for this homepage draft. The
repository title itself uses the more precise term Information Theory.

## Links

- Repository: https://github.com/km1120-code/information-theory-lab
- Interactive homepage: https://km1120-code.github.io/
- Project explanation: https://km1120-code.github.io/projects/information-theory-lab.html

## Run

Python 3.10 or newer:

```bash
python -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
python demo.py
python -m unittest discover -s tests -v
```

The demo writes a PNG figure, a CSV of the plotted observations, and a JSON
summary to `results/`. Random seeds and experimental settings are stored in the
summary. Results depend slightly on numerical-library versions.

## Files

- `core.py`: mathematical functions and algorithms.
- `demo.py`: reproducible experiment and plotting.
- `tests/test_core.py`: numerical and edge-case checks.
- `results/`: outputs from the provided experiment.

## Scope

These small CPU experiments illustrate specified models. Their observations do
not establish behavior on real data, general-purpose optimizers, or deployed
communication systems. Code is available under the MIT license.
