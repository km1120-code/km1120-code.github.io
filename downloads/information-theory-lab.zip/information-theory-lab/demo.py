from pathlib import Path
import csv
import json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from core import *

OUT = Path(__file__).parent / 'results'
OUT.mkdir(exist_ok=True)
plt.rcParams.update({'font.family': 'DejaVu Sans', 'font.size': 10,
                     'axes.spines.top': False, 'axes.spines.right': False,
                     'axes.labelcolor': '#34433e', 'text.color': '#34433e',
                     'axes.edgecolor': '#b6beb8', 'xtick.color': '#64726b',
                     'ytick.color': '#64726b', 'figure.facecolor': '#faf9f5',
                     'axes.facecolor': '#faf9f5', 'savefig.facecolor': '#faf9f5'})
GREEN, SAND, BLUE = '#235b48', '#b77c45', '#6b889a'

rng = np.random.default_rng(2026)
noise = np.linspace(0, .5, 21)
trials = 100_000
simulated = [float(np.mean((rng.random((trials, 3)) < p).sum(axis=1) >= 2)) for p in noise]
capacity = bsc_capacity(noise)
analytic = repetition_error(noise)
with (OUT / 'binary-channel.csv').open('w') as f:
    writer = csv.writer(f); writer.writerow(['flip_probability', 'capacity_bits_per_use', 'uncoded_ber', 'repetition_theory_ber', 'repetition_simulated_ber'])
    writer.writerows(zip(noise, capacity, noise, analytic, simulated))
fig, axes = plt.subplots(1, 2, figsize=(7.4, 4.4), layout='constrained')
axes[0].plot(noise, capacity, color=GREEN, linewidth=2)
axes[0].set(xlabel='Bit-flip probability, p', ylabel='Bits per channel use', title='Channel capacity')
axes[1].plot(noise, noise, '--', color=BLUE, label='Uncoded')
axes[1].plot(noise, analytic, color=GREEN, label='Repetition code: theory')
axes[1].scatter(noise, simulated, color=SAND, s=12, label='Simulation', zorder=3)
axes[1].set(xlabel='Bit-flip probability, p', ylabel='Bit error rate', title='Reliability at rate 1/3')
axes[1].legend(frameon=False, fontsize=7, loc='upper left')
for ax in axes: ax.grid(alpha=.15)
fig.savefig(OUT / 'binary-channel.png', dpi=180)
summary = {'experiment': 'memoryless binary symmetric channel', 'seed': 2026,
           'trials_per_noise_level': trials, 'repetition_code_rate': 1/3,
           'maximum_simulation_absolute_error': float(np.max(np.abs(analytic - simulated))),
           'capacity_at_p_0_1': float(bsc_capacity(.1)),
           'interpretation': 'Memoryless synthetic channel; repetition code does not achieve capacity.'}
(OUT / 'summary.json').write_text(json.dumps(summary, indent=2) + chr(10))
print(json.dumps(summary))
