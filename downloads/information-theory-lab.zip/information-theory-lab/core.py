import numpy as np

def binary_entropy(p):
    p = np.asarray(p, dtype=float)
    if np.any(~np.isfinite(p)) or np.any((p < 0) | (p > 1)):
        raise ValueError('p must be finite and in [0, 1].')
    def xlogx(x):
        safe = np.where(x > 0, x, 1.)
        return x * np.log2(safe)
    return -xlogx(p) - xlogx(1 - p)

def bsc_capacity(p):
    return 1 - binary_entropy(p)

def mutual_information(joint):
    joint = np.asarray(joint, dtype=float)
    if joint.ndim != 2 or np.any(~np.isfinite(joint)) or np.any(joint < 0) or not np.isclose(joint.sum(), 1):
        raise ValueError('A normalized, finite, nonnegative joint table is required.')
    independent = joint.sum(axis=1, keepdims=True) * joint.sum(axis=0, keepdims=True)
    mask = joint > 0
    return float(np.sum(joint[mask] * np.log2(joint[mask] / independent[mask])))

def repetition_error(p):
    p = np.asarray(p, dtype=float)
    binary_entropy(p)  # validate its probability domain
    return 3 * p * p - 2 * p * p * p
