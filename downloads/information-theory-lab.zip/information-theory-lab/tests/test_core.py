import unittest
import numpy as np
from core import binary_entropy, bsc_capacity, mutual_information, repetition_error

class InformationTests(unittest.TestCase):
    def test_entropy_boundaries(self):
        np.testing.assert_allclose(binary_entropy([0, .5, 1]), [0, 1, 0])
    def test_capacity_endpoints(self):
        np.testing.assert_allclose(bsc_capacity([0, .5]), [1, 0])
    def test_independent_variables(self):
        self.assertAlmostEqual(mutual_information([[.1, .15], [.3, .45]]), 0.)
    def test_perfectly_shared_fair_bit(self):
        self.assertAlmostEqual(mutual_information([[.5, 0], [0, .5]]), 1.)
    def test_repetition_enumeration(self):
        import itertools
        p = .2
        exact = sum(p**sum(bits) * (1-p)**(3-sum(bits)) for bits in itertools.product([0,1], repeat=3) if sum(bits)>=2)
        self.assertAlmostEqual(float(repetition_error(p)), exact)
    def test_invalid_joint_rejected(self):
        with self.assertRaises(ValueError): mutual_information([[1, 1]])
    def test_nan_rejected(self):
        with self.assertRaises(ValueError): binary_entropy(float('nan'))
